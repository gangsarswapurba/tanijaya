<div class="grid-container daftar-kategori-produk">

  <div class="grid-x kategori-produk kiri">
    <div class="cell medium-6">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/kategori/tanaman-pangan.png" />
    </div>
    <div class="cell medium-6">
      <div class="text">
        <h3 class="">Pangan</h3>
        <div class=""><a class="button primary" href="#">SELENGKAPNYA</a></div>
      </div>
    </div>
  </div>
  <div class="grid-x kategori-produk kanan">
    <div class="cell medium-6">
      <div class="text">
        <h3 class="">Sayuran</h3>
        <div class=""><a class="button primary" href="#">SELENGKAPNYA</a></div>
      </div>
    </div>
    <div class="cell medium-6">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/kategori/sayur-sayuran.png" />
    </div>
  </div>
  <div class="grid-x kategori-produk kiri">
    <div class="cell medium-6">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/kategori/buah-buahan.png" />
    </div>
    <div class="cell medium-6">
      <div class="text">
        <h3 class="">Buah</h3>
        <div class=""><a class="button primary" href="#">SELENGKAPNYA</a></div>
      </div>
    </div>
  </div>
  <div class="grid-x kategori-produk kanan">
    <div class="cell medium-6">
      <div class="text">
        <h3 class="">Rimpang</h3>
        <div class=""><a class="button primary" href="#">SELENGKAPNYA</a></div>
      </div>
    </div>
    <div class="cell medium-6">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/kategori/rimpang.png" />
    </div>
  </div>



</div><!-- .grid-container -->
