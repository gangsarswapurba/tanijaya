<div class="grid-container fluid produk-favorit">
  <div class="grid-x grid-margin-x">

    <div class="cell small-2 small-offset-1 favorit">
        <a class="produk-thumb" href="product"><img class="foto" src="<?php echo base_url(); ?>asset/img/product/iconfinder_Apple_56029.png">
        <div class="detail">
          <div class="kota">
            Madura
          </div>
          <div class="nama">
            Apel
          </div>
          <div class="harga">
            Rp150.000/kg
          </div>
        </div>
      </a>
    </div>
    <div class="cell small-2 favorit">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/product/iconfinder_Tomato_56019.png">
      <div class="detail">
        <div class="kota">
          Bantul
        </div>
        <div class="nama">
          Tomat
        </div>
        <div class="harga">
          Rp240.000/kg
        </div>
      </div>
    </div>
    <div class="cell small-2 favorit">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/product/iconfinder_Banana_56018.png">
      <div class="detail">
        <div class="kota">
          Flores
        </div>
        <div class="nama">
          Pisang
        </div>
        <div class="harga">
          Rp370.000/kg
        </div>
      </div>
    </div>
    <div class="cell small-2 favorit">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/product/iconfinder_Lemon_56022.png">
      <div class="detail">
        <div class="kota">
          Sleman
        </div>
        <div class="nama">
          Jeruk
        </div>
        <div class="harga">
          Rp129.000/kg
        </div>
      </div>
    </div>
    <div class="cell small-2 favorit">
      <img class="foto" src="<?php echo base_url(); ?>asset/img/product/iconfinder_Pear_56020.png">
      <div class="detail">
        <div class="kota">
          Gunung Kidul
        </div>
        <div class="nama">
          Pear
        </div>
        <div class="harga">
          Rp350.000/kg
        </div>
      </div>
    </div>

  </div>
</div>
