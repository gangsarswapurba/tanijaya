<div class="grid-container cart">
  <h2>Pesanan anda</h2>
  <div class="grid-x item">
    <div class="cell medium-2 foto-thumb">
      <img src="img/product/iconfinder_Apple_56029.png" alt="">
    </div>
    <div class="cell medium-4 deskripsi">
      Apel Madura (1kg)
    </div>
    <div class="cell medium-5 qty">
      <label for="qty-stepper"> QTY:</label>
      <input id="qty-stepper" class='' type="number" placeholder="" value="1" min="0">
    </div>
    <div class="cell medium-1">
      <a href="#"><ion-icon name="close-circle-outline"></ion-icon></a>
    </div>
  </div>
</div>
