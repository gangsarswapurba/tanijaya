<div class="grid-container produk">
  <div class="grid-x">
    <div class="cell medium-6">
      <img class="foto-utama" src="<?php echo base_url(); ?>asset/img/product/iconfinder_Apple_56029x512.png" alt="">
    </div>
    <div class="cell medium-6">
      <h3 class="kota">Madura</h3>
      <h2 class="nama">Apel</h2>
      <h4 class="satuan">(1kg)</h4>
      <div class="grid-x">
        <div class="cell medium-6">
          <div class="harga">
            <span class="harga-lama">Rp7.500.000</span><br />
            <span class="harga">Rp150.000</span>
          </div>
        </div>
        <div class="cell medium-6">
          <a href="cart" class="button primary beli" type="button" name="button">BELI</a>
        </div>
      </div>
      <div class="separator">

      </div>
      <h5 class="deskripsi-title">DESKRIPSI</h5>
      <div class="deskripsi">
        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Etiam porta sem malesuada magna mollis euismod. Etiam porta sem malesuada magna mollis euismod. Maecenas sed diam eget risus varius blandit sit amet non magna. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Maecenas sed diam eget risus varius blandit sit amet magna charta.</p>
      </div>
    </div>
  </div>
</div><!-- .grid-container -->
